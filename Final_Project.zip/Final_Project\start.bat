﻿@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ========================================
echo   「兔了个」文案助手 · HTML PPT
echo ========================================
echo.
echo 正在启动本地预览服务器...
start "" cmd /c "timeout /t 1 /nobreak >nul & start http://127.0.0.1:8777/index.html"
python -m http.server 8777
if errorlevel 1 (
  echo.
  echo [错误] 未检测到 Python。请安装 Python 后重试，
  echo 或直接用浏览器打开本目录下的 index.html（部分功能可能受限）。
  pause
)
